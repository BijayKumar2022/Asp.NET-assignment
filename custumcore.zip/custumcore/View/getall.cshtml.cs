using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace custumcore.View
{
    public class getallModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
