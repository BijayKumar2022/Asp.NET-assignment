using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace custumcore.View
{
    public class getModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
