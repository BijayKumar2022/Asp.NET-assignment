using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace custumcore.View
{
    public class loginModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}