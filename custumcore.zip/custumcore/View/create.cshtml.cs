using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace custumcore.View
{
    public class createModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
